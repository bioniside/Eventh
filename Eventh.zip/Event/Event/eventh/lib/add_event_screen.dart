import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'services/database_helper.dart';
import 'admin_dashboard_screen.dart';
import 'main.dart'; // For custom colors

class AddEventScreen extends StatefulWidget {
  final Map<String, dynamic>? eventToEdit;
  final Map<String, dynamic> user; // Added user parameter

  const AddEventScreen({super.key, this.eventToEdit, required this.user});

  @override
  State<AddEventScreen> createState() => _AddEventScreenState();
}

class _AddEventScreenState extends State<AddEventScreen> {
  final _nameController = TextEditingController();
  final _dateController = TextEditingController();
  final _locationController = TextEditingController();
  final _descriptionController = TextEditingController();
  String? _imagePath;

  // This list will now correctly hold and manage the tiers
  List<Map<String, dynamic>> _ticketTiers = [];

  @override
  void initState() {
    super.initState();
    if (widget.eventToEdit != null) {
      _nameController.text = widget.eventToEdit![DatabaseHelper.columnName];
      _dateController.text = widget.eventToEdit![DatabaseHelper.columnDate];
      _locationController.text = widget.eventToEdit![DatabaseHelper.columnLocation];
      _descriptionController.text = widget.eventToEdit![DatabaseHelper.columnDescription];
      _imagePath = widget.eventToEdit![DatabaseHelper.columnImage];
      _loadTicketTiers(widget.eventToEdit![DatabaseHelper.columnId]);
    }
  }

  void _loadTicketTiers(int eventId) async {
    final tickets = await DatabaseHelper.instance.queryTicketsForEvent(eventId);
    setState(() {
      // Correctly clone the tickets to avoid modification issues
      _ticketTiers = tickets.map((t) => Map<String, dynamic>.from(t)).toList();
    });
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      final appDir = await getApplicationDocumentsDirectory();
      final fileName = p.basename(pickedFile.path);
      final savedImage = await File(pickedFile.path).copy('${appDir.path}/$fileName');
      setState(() {
        _imagePath = savedImage.path;
      });
    }
  }

  Future<void> _selectDate() async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
      builder: (context, child) {
        return Theme(
          data: ThemeData.light().copyWith(
            colorScheme: const ColorScheme.light(primary: primaryPurple),
          ),
          child: child!,
        );
      },
    );
    if (picked != null) {
      setState(() {
        _dateController.text = DateFormat.yMMMd().format(picked);
      });
    }
  }

  void _addTicketTier() {
    setState(() {
      _ticketTiers.add({
        DatabaseHelper.columnTicketType: 'Regular',
        DatabaseHelper.columnTicketPrice: 50.0,
        DatabaseHelper.columnTicketQuantity: 100,
      });
    });
  }

  void _removeTicketTier(int index) {
    setState(() {
      _ticketTiers.removeAt(index);
    });
  }

  void _saveEvent() async {
    final name = _nameController.text;
    final date = _dateController.text;
    final location = _locationController.text;
    final description = _descriptionController.text;

    if (name.isEmpty || date.isEmpty || location.isEmpty || description.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please fill all fields')));
      return;
    }

    Map<String, dynamic> eventData = {
      DatabaseHelper.columnName: name,
      DatabaseHelper.columnDate: date,
      DatabaseHelper.columnLocation: location,
      DatabaseHelper.columnDescription: description,
      DatabaseHelper.columnImage: _imagePath,
    };

    int eventId;
    if (widget.eventToEdit != null) {
      eventId = widget.eventToEdit![DatabaseHelper.columnId];
      eventData[DatabaseHelper.columnId] = eventId;
      await DatabaseHelper.instance.updateEvent(eventData);
      // CRITICAL FIX: Delete existing tickets before adding the updated list
      await DatabaseHelper.instance.deleteTicketsForEvent(eventId);
    } else {
      eventId = await DatabaseHelper.instance.insertEvent(eventData);
      final users = await DatabaseHelper.instance.queryAllUsers();
      for (final user in users) {
        await DatabaseHelper.instance.insertNotification({
          DatabaseHelper.columnNotificationUserId: user[DatabaseHelper.columnUserId],
          DatabaseHelper.columnNotificationTitle: 'New Event Added',
          DatabaseHelper.columnNotificationBody: 'A new event, \'$name\', has been added.',
          DatabaseHelper.columnNotificationTimestamp: DateTime.now().millisecondsSinceEpoch,
        });
      }
    }

    // Re-insert all tiers from the state, ensuring they are saved correctly
    for (final tier in _ticketTiers) {
      await DatabaseHelper.instance.insertTicket({
        DatabaseHelper.columnTicketEventId: eventId,
        DatabaseHelper.columnTicketType: tier[DatabaseHelper.columnTicketType],
        DatabaseHelper.columnTicketPrice: tier[DatabaseHelper.columnTicketPrice],
        DatabaseHelper.columnTicketQuantity: tier[DatabaseHelper.columnTicketQuantity],
      });
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          widget.eventToEdit != null ? 'Event updated successfully!' : 'Event added successfully!',
        ),
      ),
    );

    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(
        builder: (context) => AdminDashboardScreen(user: widget.user),
      ),
      (Route<dynamic> route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.eventToEdit != null ? 'Edit Event' : 'Add Event'),
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                    labelText: 'Event Name', prefixIcon: Icon(Icons.title)),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _dateController,
                decoration: const InputDecoration(
                  labelText: 'Event Date',
                  prefixIcon: Icon(Icons.calendar_today),
                ),
                readOnly: true,
                onTap: _selectDate,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _locationController,
                decoration: const InputDecoration(
                    labelText: 'Event Location', prefixIcon: Icon(Icons.location_on_outlined)),
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _descriptionController,
                decoration: const InputDecoration(
                    labelText: 'Event Description', prefixIcon: Icon(Icons.description_outlined)),
                maxLines: 3,
              ),
              const SizedBox(height: 24),
              _buildImagePicker(),
              const SizedBox(height: 24),
              const Text(
                'Ticket Tiers',
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: primaryPurple),
              ),
              const SizedBox(height: 12),
              ..._ticketTiers.asMap().entries.map((entry) {
                int index = entry.key;
                return _TicketTierCard(index: index, tiers: _ticketTiers, onRemove: _removeTicketTier);
              }),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                onPressed: _addTicketTier,
                icon: const Icon(Icons.add),
                label: const Text('Add Ticket Tier'),
                style: OutlinedButton.styleFrom(foregroundColor: primaryPurple),
              ),
              const SizedBox(height: 24),
              ElevatedButton.icon(
                onPressed: _saveEvent,
                icon: Icon(widget.eventToEdit != null ? Icons.save_alt : Icons.add_circle_outline),
                label: Text(widget.eventToEdit != null ? 'Update Event' : 'Add Event'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildImagePicker() {
    return GestureDetector(
      onTap: _pickImage,
      child: Container(
        height: 150,
        decoration: BoxDecoration(
          color: Colors.grey.shade200,
          borderRadius: BorderRadius.circular(15),
          border: Border.all(color: Colors.grey.shade300, width: 1),
        ),
        child: _imagePath != null
            ? ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: Image.file(
                  File(_imagePath!),
                  fit: BoxFit.cover,
                  width: double.infinity,
                ),
              )
            : const Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.add_a_photo_outlined, color: primaryPurple, size: 40),
                    SizedBox(height: 8),
                    Text('Tap to select an image', style: TextStyle(color: Colors.grey)),
                  ],
                ),
              ),
      ),
    );
  }
}

class _TicketTierCard extends StatelessWidget {
  final int index;
  final List<Map<String, dynamic>> tiers;
  final Function(int) onRemove;

  const _TicketTierCard({required this.index, required this.tiers, required this.onRemove});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Ticket Tier', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                IconButton(
                  icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                  onPressed: () => onRemove(index),
                ),
              ],
            ),
            const SizedBox(height: 8),
            TextFormField(
              initialValue: tiers[index][DatabaseHelper.columnTicketType],
              decoration: const InputDecoration(labelText: 'Tier Name'),
              onChanged: (value) => tiers[index][DatabaseHelper.columnTicketType] = value,
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    initialValue: tiers[index][DatabaseHelper.columnTicketPrice].toString(),
                    decoration: const InputDecoration(labelText: 'Price', prefixIcon: Icon(Icons.attach_money)),
                    keyboardType: TextInputType.number,
                    onChanged: (value) =>
                        tiers[index][DatabaseHelper.columnTicketPrice] = double.tryParse(value) ?? 0.0,
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextFormField(
                    initialValue: tiers[index][DatabaseHelper.columnTicketQuantity].toString(),
                    decoration: const InputDecoration(labelText: 'Quantity', prefixIcon: Icon(Icons.people_outline)),
                    keyboardType: TextInputType.number,
                    onChanged: (value) =>
                        tiers[index][DatabaseHelper.columnTicketQuantity] = int.tryParse(value) ?? 0,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
