import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'main.dart'; // Import custom colors
import 'booked_tickets_screen.dart';
import 'login_screen.dart';
import 'settings_screen.dart';
import 'services/database_helper.dart';

class ProfileScreen extends StatefulWidget {
  final int userId;

  const ProfileScreen({super.key, required this.userId});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late Future<Map<String, dynamic>?> _userFuture;
  File? _image;
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _userFuture = _getUser();
  }

  Future<Map<String, dynamic>?> _getUser() async {
    final user = await DatabaseHelper.instance.getUser(widget.userId);
    if (user != null) {
      final imagePath = user[DatabaseHelper.columnUserProfileImage];
      if (imagePath != null && imagePath.isNotEmpty) {
        if (mounted) {
          setState(() {
            _image = File(imagePath);
          });
        }
      }
    }
    return user;
  }

  Future<void> _pickImage(int userId) async {
    final XFile? pickedFile = await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      final appDir = await getApplicationDocumentsDirectory();
      final fileName = p.basename(pickedFile.path);
      final savedImage = await File(pickedFile.path).copy('${appDir.path}/$fileName');

      await DatabaseHelper.instance.updateUserProfileImage(userId, savedImage.path);
      if (mounted) {
        setState(() {
          _image = savedImage;
        });
      }
    }
  }

  void _handleLogout(BuildContext context) {
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (context) => const LoginScreen()),
      (Route<dynamic> route) => false,
    );
  }

  void _navigateToMyTickets(BuildContext context, Map<String, dynamic> user) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => BookedTicketsScreen(user: user)),
    );
  }

  void _navigateToSettings(BuildContext context, Map<String, dynamic> user) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => SettingsScreen(user: user)),
    ).then((_) {
      setState(() {
        _userFuture = _getUser();
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: true,
      ),
      body: FutureBuilder<Map<String, dynamic>?>(
        future: _userFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError || !snapshot.hasData || snapshot.data == null) {
            return const Center(child: Text('Could not load profile. Please try again.'));
          }

          final user = snapshot.data!;
          final userId = user[DatabaseHelper.columnUserId];

          return Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Center(
                          child: Stack(
                            children: [
                              CircleAvatar(
                                radius: 50,
                                backgroundColor: primaryBlue,
                                backgroundImage: _image != null ? FileImage(_image!) : null,
                                child: _image == null
                                    ? const Icon(Icons.person, size: 60, color: Colors.white)
                                    : null,
                              ),
                              Positioned(
                                bottom: 0,
                                right: 0,
                                child: CircleAvatar(
                                  radius: 18,
                                  backgroundColor: primaryPurple,
                                  child: IconButton(
                                    icon: const Icon(Icons.edit, color: Colors.white, size: 18),
                                    onPressed: () => _pickImage(userId),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),
                        Text(
                          user[DatabaseHelper.columnUserFullName] ?? 'No Name',
                          style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          user[DatabaseHelper.columnUserEmail] ?? 'No Email',
                          style: TextStyle(fontSize: 16, color: Colors.grey.shade600),
                        ),
                        const SizedBox(height: 20),
                        Card(
                          elevation: 2,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Column(
                            children: [
                              ListTile(
                                leading: const Icon(Icons.phone_outlined, color: primaryPurple),
                                title: const Text('Phone Number'),
                                subtitle: Text(user[DatabaseHelper.columnUserPhoneNumber] ?? 'Not provided'),
                              ),
                              const Divider(height: 0),
                              ListTile(
                                leading: const Icon(Icons.wc_outlined, color: primaryPurple),
                                title: const Text('Gender'),
                                subtitle: Text(user[DatabaseHelper.columnUserGender] ?? 'Not provided'),
                              ),
                              const Divider(height: 0),
                              ListTile(
                                leading: const Icon(Icons.location_on_outlined, color: primaryPurple),
                                title: const Text('Location'),
                                subtitle: Text(user[DatabaseHelper.columnUserLocation] ?? 'Not provided'),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 20),
                        Card(
                          elevation: 2,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                          child: Column(
                            children: [
                              ListTile(
                                leading: const Icon(Icons.confirmation_number_outlined, color: primaryPurple),
                                title: const Text('My Tickets'),
                                trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                                onTap: () => _navigateToMyTickets(context, user),
                              ),
                              const Divider(height: 0),
                              ListTile(
                                leading: const Icon(Icons.settings_outlined, color: primaryPurple),
                                title: const Text('Settings'),
                                trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                                onTap: () => _navigateToSettings(context, user),
                              ),
                              const Divider(height: 0),
                              ListTile(
                                leading: const Icon(Icons.privacy_tip_outlined, color: primaryPurple),
                                title: const Text('Privacy Policy'),
                                trailing: const Icon(Icons.arrow_forward_ios, size: 16),
                                onTap: () {},
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                ElevatedButton.icon(
                  icon: const Icon(Icons.logout, color: Colors.white),
                  label: const Text('Logout'),
                  onPressed: () => _handleLogout(context),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red.shade400,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    textStyle: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
