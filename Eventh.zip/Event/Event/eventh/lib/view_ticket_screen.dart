import 'package:flutter/material.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:eventh/services/database_helper.dart';

class ViewTicketScreen extends StatelessWidget {
  final Map<String, dynamic> bookedTicket;

  const ViewTicketScreen({super.key, required this.bookedTicket});

  @override
  Widget build(BuildContext context) {
    // QR data now includes user details for security and verification.
    final qrData = 'Event: ${bookedTicket[DatabaseHelper.columnName]}\n'
        'Ticket Type: ${bookedTicket[DatabaseHelper.columnTicketType]}\n'
        'Price: \$${bookedTicket[DatabaseHelper.columnTicketPrice]}\n'
        'Name: ${bookedTicket[DatabaseHelper.columnUserFullName]}\n'
        'Phone: ${bookedTicket[DatabaseHelper.columnUserPhoneNumber]}';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Your Ticket'),
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                bookedTicket[DatabaseHelper.columnName] ?? 'Event Name',
                style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Text(
                'Date: ${bookedTicket[DatabaseHelper.columnDate] ?? 'N/A'}',
                style: TextStyle(fontSize: 16, color: Colors.grey.shade600),
              ),
              const SizedBox(height: 32),
              QrImageView(
                data: qrData,
                version: QrVersions.auto,
                size: 200.0,
                backgroundColor: Colors.white,
              ),
              const SizedBox(height: 32),
              const Text(
                'Present this QR code at the event entrance for scanning.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16, color: Colors.grey),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
