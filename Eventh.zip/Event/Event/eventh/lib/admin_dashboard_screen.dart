import 'dart:io';
import 'package:flutter/material.dart';
import 'main.dart'; // Import custom colors
import 'add_event_screen.dart'; // Import the screen for adding/editing events
import 'login_screen.dart'; // Import the login screen
import 'services/database_helper.dart';
import 'booked_ticket_detail_screen.dart';
import 'admin_profile_screen.dart'; // Import the admin profile screen
import 'admin_change_password_screen.dart'; // Import the change password screen
import 'admin_settings_screen.dart'; // Import the admin settings screen
import 'user_detail_screen.dart'; // Import the user detail screen
import 'create_admin_screen.dart'; // Import the create admin screen

class AdminDashboardScreen extends StatefulWidget {
  final Map<String, dynamic> user;
  const AdminDashboardScreen({super.key, required this.user});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  late Future<List<Map<String, dynamic>>> _eventsFuture;
  late Future<List<Map<String, dynamic>>> _usersFuture;
  late Future<List<Map<String, dynamic>>> _eventTicketDetailsFuture;
  late Future<List<Map<String, dynamic>>> _allBookedTicketsFuture;

  @override
  void initState() {
    super.initState();
    _refreshData();
  }

  void _refreshData() {
    setState(() {
      _eventsFuture = DatabaseHelper.instance.queryAllEvents();
      _usersFuture = DatabaseHelper.instance.queryAllUsers();
      _eventTicketDetailsFuture = DatabaseHelper.instance.getEventTicketDetails();
      _allBookedTicketsFuture = DatabaseHelper.instance.getAllJoinedBookedTickets();
    });
  }

  void _handleEditEvent(BuildContext context, Map<String, dynamic> event) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => AddEventScreen(eventToEdit: event, user: widget.user),
      ),
    ).then((_) => _refreshData());
  }

  void _handleAddNewEvent(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => AddEventScreen(user: widget.user)),
    ).then((_) => _refreshData());
  }

  void _handleDeleteEvent(int eventId) {
    showDialog(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        title: const Text('Confirm Deletion'),
        content: const Text('Are you sure you want to delete this event?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              await DatabaseHelper.instance.deleteEvent(eventId);
              Navigator.of(ctx).pop();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Event deleted successfully')),
              );
              _refreshData();
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _handleDeleteUser(Map<String, dynamic> userToDelete) {
    final currentAdminId = widget.user[DatabaseHelper.columnUserId];
    final userIdToDelete = userToDelete[DatabaseHelper.columnUserId];

    if (userIdToDelete == currentAdminId) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('You cannot delete your own admin account.')),
      );
      return;
    }

    showDialog(
      context: context,
      builder: (BuildContext ctx) => AlertDialog(
        title: const Text('Confirm Deletion'),
        content: const Text('Are you sure you want to delete this user?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () async {
              await DatabaseHelper.instance.deleteUser(userIdToDelete);
              Navigator.of(ctx).pop();
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('User deleted successfully')),
              );
              _refreshData();
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  void _handleLogout() {
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (context) => const LoginScreen()),
      (Route<dynamic> route) => false,
    );
  }

  void _navigateToChangePassword() {
    final adminId = widget.user[DatabaseHelper.columnUserId];
    Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => AdminChangePasswordScreen(userId: adminId)),
    );
  }

  void _navigateToAdminProfile() {
    final adminId = widget.user[DatabaseHelper.columnUserId];
    Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => AdminProfileScreen(userId: adminId)),
    );
  }

  void _navigateToAdminSettings() {
    final adminId = widget.user[DatabaseHelper.columnUserId];
    Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => AdminSettingsScreen(userId: adminId)),
    );
  }

  void _navigateToCreateAdmin() {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (context) => const CreateAdminScreen()),
    ).then((_) => _refreshData());
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Admin Dashboard'),
          backgroundColor: primaryPurple,
          foregroundColor: Colors.white,
          centerTitle: true,
          actions: [
            IconButton(
              icon: const Icon(Icons.person_outline),
              onPressed: _navigateToAdminProfile,
            ),
          ],
          bottom: const TabBar(
            indicatorColor: Colors.white,
            tabs: [
              Tab(icon: Icon(Icons.event), text: 'Events'),
              Tab(icon: Icon(Icons.people), text: 'Users'),
              Tab(icon: Icon(Icons.confirmation_number), text: 'Tickets'),
              Tab(icon: Icon(Icons.book_online), text: 'Booked'),
            ],
          ),
        ),
        drawer: Drawer(
          child: ListView(
            padding: EdgeInsets.zero,
            children: <Widget>[
              DrawerHeader(
                decoration: const BoxDecoration(color: primaryPurple),
                child: Text(
                  'Admin Menu', 
                  style: const TextStyle(color: Colors.white, fontSize: 24),
                ),
              ),
              ListTile(
                leading: const Icon(Icons.person_outline),
                title: const Text('Admin Profile'),
                onTap: () {
                  Navigator.pop(context);
                  _navigateToAdminProfile();
                },
              ),
              ListTile(
                leading: const Icon(Icons.settings_outlined),
                title: const Text('Settings'),
                onTap: () {
                  Navigator.pop(context);
                  _navigateToAdminSettings();
                },
              ),
              ListTile(
                leading: const Icon(Icons.add_moderator_outlined),
                title: const Text('Create New Admin'),
                onTap: () {
                  Navigator.pop(context);
                  _navigateToCreateAdmin();
                },
              ),
              ListTile(
                leading: const Icon(Icons.lock_outline),
                title: const Text('Change Password'),
                onTap: () {
                  Navigator.pop(context);
                  _navigateToChangePassword();
                },
              ),
              ListTile(
                leading: const Icon(Icons.logout),
                title: const Text('Logout'),
                onTap: () {
                  Navigator.pop(context);
                  _handleLogout();
                },
              ),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            _buildFutureBuilder(_eventsFuture, (data) => _ManageEventsView(
              adminEvents: data,
              onEditEvent: (event) => _handleEditEvent(context, event),
              onDeleteEvent: (eventId) => _handleDeleteEvent(eventId),
            )),
            _buildFutureBuilder(_usersFuture, (data) => _ManageUsersView(users: data, onDeleteUser: _handleDeleteUser)),
            _buildFutureBuilder(_eventTicketDetailsFuture, (data) => _ManageTicketsView(eventTicketDetails: data)),
            _buildFutureBuilder(_allBookedTicketsFuture, (data) => _ManageBookedTicketsView(bookedTickets: data)),
          ],
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => _handleAddNewEvent(context),
          label: const Text('Add New Event'),
          icon: const Icon(Icons.add),
        ),
      ),
    );
  }

  Widget _buildFutureBuilder(
    Future<List<Map<String, dynamic>>> future,
    Widget Function(List<Map<String, dynamic>> data) builder,
  ) {
    return FutureBuilder<List<Map<String, dynamic>>>(
      future: future,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        if (snapshot.hasError) {
          return Center(child: Text('Error loading data: ${snapshot.error}'));
        }
        final data = snapshot.data ?? [];
        if (data.isEmpty) {
          return const Center(child: Text('No data available.'));
        }
        return builder(data);
      },
    );
  }
}

class _ManageEventsView extends StatelessWidget {
  final List<Map<String, dynamic>> adminEvents;
  final Function(Map<String, dynamic>) onEditEvent;
  final Function(int) onDeleteEvent;

  const _ManageEventsView({
    required this.adminEvents,
    required this.onEditEvent,
    required this.onDeleteEvent,
  });

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: adminEvents.length,
      itemBuilder: (context, index) {
        final event = adminEvents[index];
        return _AdminEventTile(
          event: event,
          onEdit: () => onEditEvent(event),
          onDelete: () => onDeleteEvent(event[DatabaseHelper.columnId]),
        );
      },
    );
  }
}

class _ManageUsersView extends StatelessWidget {
  final List<Map<String, dynamic>> users;
  final Function(Map<String, dynamic>) onDeleteUser;

  const _ManageUsersView({required this.users, required this.onDeleteUser});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(16.0),
      itemCount: users.length,
      itemBuilder: (context, index) {
        final user = users[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 8.0),
          child: ListTile(
            leading: const Icon(Icons.person, color: primaryPurple),
            title: Text(user[DatabaseHelper.columnUserEmail] ?? 'N/A'),
            trailing: IconButton(
              icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
              onPressed: () => onDeleteUser(user),
            ),
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => UserDetailScreen(user: user),
                ),
              );
            },
          ),
        );
      },
    );
  }
}

class _ManageTicketsView extends StatelessWidget {
  final List<Map<String, dynamic>> eventTicketDetails;

  const _ManageTicketsView({required this.eventTicketDetails});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(16.0),
      itemCount: eventTicketDetails.length,
      itemBuilder: (context, index) {
        final details = eventTicketDetails[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 8.0),
          child: ListTile(
            leading: const Icon(Icons.confirmation_number, color: primaryPurple),
            title: Text(details[DatabaseHelper.columnName] ?? 'N/A'),
            subtitle: Text(
                'Total: ${details['total_tickets']} | Booked: ${details['booked_tickets']} | Remaining: ${details['remaining_tickets']}'),
          ),
        );
      },
    );
  }
}

class _ManageBookedTicketsView extends StatelessWidget {
  final List<Map<String, dynamic>> bookedTickets;

  const _ManageBookedTicketsView({required this.bookedTickets});

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      padding: const EdgeInsets.all(16.0),
      itemCount: bookedTickets.length,
      itemBuilder: (context, index) {
        final bookedTicket = bookedTickets[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 8.0),
          child: ListTile(
            leading: const Icon(Icons.book_online, color: primaryPurple),
            title: Text('${bookedTicket[DatabaseHelper.columnUserFullName]} - ${bookedTicket[DatabaseHelper.columnName]}'),
            subtitle: Text('Ticket: ${bookedTicket[DatabaseHelper.columnTicketType]} - Status: ${bookedTicket[DatabaseHelper.columnBookedStatus]}'),
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => BookedTicketDetailScreen(bookedTicket: bookedTicket),
                ),
              );
            },
          ),
        );
      },
    );
  }
}

class _AdminEventTile extends StatelessWidget {
  final Map<String, dynamic> event;
  final VoidCallback onEdit;
  final VoidCallback onDelete;

  const _AdminEventTile({
    required this.event,
    required this.onEdit,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final imagePath = event[DatabaseHelper.columnImage] as String?;

    Widget imageWidget;
    if (imagePath != null && imagePath.isNotEmpty) {
      if (imagePath.startsWith('http')) {
        imageWidget = Image.network(
          imagePath,
          fit: BoxFit.cover,
          errorBuilder: (context, error, stackTrace) =>
              const Icon(Icons.error_outline, color: Colors.red),
        );
      } else {
        imageWidget = Image.file(
          File(imagePath),
          fit: BoxFit.cover,
          errorBuilder: (context, error, stackTrace) =>
              const Icon(Icons.broken_image_outlined, color: Colors.grey),
        );
      }
    } else {
      imageWidget = Container(
        decoration: BoxDecoration(
          color: primaryBlue.withOpacity(0.2),
          borderRadius: BorderRadius.circular(8.0),
        ),
        child: const Icon(Icons.event, color: primaryPurple, size: 30),
      );
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: SizedBox(
          width: 60,
          height: 60,
          child: ClipRRect(
            borderRadius: BorderRadius.circular(8.0),
            child: imageWidget,
          ),
        ),
        title: Text(
          event[DatabaseHelper.columnName] ?? 'N/A',
          style: const TextStyle(fontWeight: FontWeight.bold),
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Date: ${event[DatabaseHelper.columnDate] ?? 'N/A'}'),
            Text('Location: ${event[DatabaseHelper.columnLocation] ?? 'N/A'}'),
          ],
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: const Icon(Icons.edit, color: primaryBlue),
              onPressed: onEdit,
            ),
            IconButton(
              icon: const Icon(Icons.delete, color: Colors.redAccent),
              onPressed: onDelete,
            ),
          ],
        ),
        onTap: onEdit,
      ),
    );
  }
}
