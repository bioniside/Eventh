import 'dart:io';
import 'package:flutter/material.dart';
import 'main.dart';
import 'services/database_helper.dart';
import 'payment_screen.dart';
import 'profile_screen.dart';

class EventDetailScreen extends StatefulWidget {
  final Map<String, dynamic> event;
  final int userId;

  const EventDetailScreen({super.key, required this.event, required this.userId});

  @override
  State<EventDetailScreen> createState() => _EventDetailScreenState();
}

class _EventDetailScreenState extends State<EventDetailScreen> {
  late Future<List<Map<String, dynamic>>> _ticketsFuture;
  late Future<Map<String, dynamic>?> _userFuture;

  @override
  void initState() {
    super.initState();
    final eventId = widget.event[DatabaseHelper.columnId];
    _userFuture = DatabaseHelper.instance.getUser(widget.userId);
    if (eventId != null) {
      _ticketsFuture = DatabaseHelper.instance.queryTicketsForEvent(eventId);
    } else {
      _ticketsFuture = Future.value([]);
    }
  }

  void _bookTicket(Map<String, dynamic> ticket, Map<String, dynamic> user) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => PaymentScreen(event: widget.event, ticket: ticket, user: user),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final imagePath = widget.event[DatabaseHelper.columnImage];
    final devicePixelRatio = MediaQuery.of(context).devicePixelRatio;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.event[DatabaseHelper.columnName] ?? 'Event Details'),
        backgroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.person_outline),
            onPressed: () {
              Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (context) => ProfileScreen(userId: widget.userId),
                ),
              );
            },
          ),
        ],
      ),
      body: CustomScrollView(
        slivers: [
          SliverToBoxAdapter(
            child: RepaintBoundary(
              child: Container(
                height: 200,
                width: double.infinity,
                color: primaryBlue.withOpacity(0.2),
                child: imagePath != null && (imagePath as String).isNotEmpty
                    ? Image.file(
                        File(imagePath),
                        fit: BoxFit.cover,
                        cacheHeight: (200 * devicePixelRatio).round(),
                      )
                    : Center(
                        child: Icon(
                          Icons.event,
                          size: 100,
                          color: primaryPurple.withOpacity(0.5),
                        ),
                      ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.all(24.0),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                Text(
                  widget.event[DatabaseHelper.columnName] ?? 'Event Name Not Available',
                  style: const TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    const Icon(
                      Icons.calendar_today,
                      size: 18,
                      color: primaryPurple,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      widget.event[DatabaseHelper.columnDate] ?? 'Date not available',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey.shade700,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    const Icon(
                      Icons.location_on,
                      size: 18,
                      color: primaryPurple,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      widget.event[DatabaseHelper.columnLocation] ?? 'Location not available',
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.grey.shade700,
                      ),
                    ),
                  ],
                ),
                const Divider(height: 32),
                const Text(
                  'About this event',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),
                Text(
                  widget.event[DatabaseHelper.columnDescription] ?? 'Description not available.',
                  style: TextStyle(
                    fontSize: 16,
                    height: 1.5,
                    color: Colors.grey.shade700,
                  ),
                ),
                const SizedBox(height: 30),
                const Text(
                  'Tickets',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
              ]),
            ),
          ),
          FutureBuilder<List<Map<String, dynamic>>>(
            future: _ticketsFuture,
            builder: (context, ticketSnapshot) {
              if (ticketSnapshot.connectionState == ConnectionState.waiting) {
                return const SliverToBoxAdapter(
                  child: Center(child: CircularProgressIndicator()),
                );
              }
              if (ticketSnapshot.hasError) {
                return const SliverToBoxAdapter(
                  child: Center(child: Text('Error loading tickets')),
                );
              }
              final tickets = ticketSnapshot.data ?? [];
              if (tickets.isEmpty) {
                return const SliverToBoxAdapter(
                  child: Center(child: Text('No tickets available.')),
                );
              }
              return SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    final ticket = tickets[index];
                    return FutureBuilder<Map<String, dynamic>?>(
                      future: _userFuture,
                      builder: (context, userSnapshot) {
                        if (userSnapshot.connectionState == ConnectionState.waiting) {
                          return const Center(child: CircularProgressIndicator());
                        }
                        if (userSnapshot.hasError || !userSnapshot.hasData) {
                          return const Center(child: Text('Error loading user data'));
                        }
                        final user = userSnapshot.data!;
                        return Container(
                          margin: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 4.0),
                          decoration: BoxDecoration(
                            border: Border(bottom: BorderSide(color: Colors.grey.shade300)),
                          ),
                          child: ListTile(
                            title: Text(ticket[DatabaseHelper.columnTicketType] ?? 'Ticket'),
                            subtitle: Text(
                                '\$${ticket[DatabaseHelper.columnTicketPrice] ?? 0} - ${ticket[DatabaseHelper.columnTicketQuantity] ?? 0} available'),
                            trailing: ElevatedButton(
                              onPressed: () => _bookTicket(ticket, user),
                              child: const Text('Book'),
                            ),
                          ),
                        );
                      },
                    );
                  },
                  childCount: tickets.length,
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
