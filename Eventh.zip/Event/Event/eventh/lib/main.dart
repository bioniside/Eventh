import 'package:flutter/foundation.dart' show kIsWeb;
import 'package:flutter/material.dart';
import 'login_screen.dart'; // Import the first screen
import 'services/database_helper.dart'; // Import the database helper

// Define custom colors based on the design mockups
const Color primaryPurple = Color(0xFF4C2FEE);
const Color primaryBlue = Color(0xFF673AB7); // Secondary purple/indigo

void main() async { // Make the main function async
  // Ensure that the Flutter widgets are initialized.
  WidgetsFlutterBinding.ensureInitialized();

  // Only initialize the database if the app is NOT running on the web
  if (!kIsWeb) {
    // await DatabaseHelper.instance.deleteDatabase(); // Commented out to persist data
    await DatabaseHelper.instance.database;
  }

  runApp(const EventsConnectApp());
}

class EventsConnectApp extends StatelessWidget {
  const EventsConnectApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Events Connect',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        // Set the primary color for buttons, app bars, etc.
        primaryColor: primaryPurple,
        // Define color scheme based on the primary color
        colorScheme: ColorScheme.fromSwatch(primarySwatch: Colors.deepPurple)
            .copyWith(
              secondary: primaryBlue, // Accent color
              primary: primaryPurple,
            ),
        // Global style for elevated buttons
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: primaryPurple, // Background color
            foregroundColor: Colors.white, // Text color
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            textStyle: const TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        // Global style for input fields
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: BorderSide.none, // Hide default border for filled fields
          ),
          filled: true,
          fillColor: Colors.grey.shade100,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 16,
            vertical: 12,
          ),
        ),
        useMaterial3: true,
      ),
      // Start the app on the Login Screen
      home: const LoginScreen(),
    );
  }
}
