import 'package:flutter/material.dart';
import 'package:eventh/services/database_helper.dart';
import 'main.dart';

class BookedTicketDetailScreen extends StatelessWidget {
  final Map<String, dynamic> bookedTicket;

  const BookedTicketDetailScreen({super.key, required this.bookedTicket});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Booked Ticket Details'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Card(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          elevation: 4,
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildSectionTitle(context, 'Event Details'),
                _buildDetailRow('Name', bookedTicket[DatabaseHelper.columnName]),
                _buildDetailRow('Date', bookedTicket[DatabaseHelper.columnDate]),
                _buildDetailRow('Location', bookedTicket[DatabaseHelper.columnLocation]),
                const SizedBox(height: 16),
                _buildSectionTitle(context, 'User Details'),
                _buildDetailRow('Name', bookedTicket[DatabaseHelper.columnUserFullName]),
                _buildDetailRow('Email', bookedTicket[DatabaseHelper.columnUserEmail]),
                _buildDetailRow('Phone', bookedTicket[DatabaseHelper.columnUserPhoneNumber]),
                const SizedBox(height: 16),
                _buildSectionTitle(context, 'Ticket Details'),
                _buildDetailRow('Type', bookedTicket[DatabaseHelper.columnTicketType]),
                _buildDetailRow('Price', '\$${bookedTicket[DatabaseHelper.columnTicketPrice]}'),
                _buildDetailRow('Status', bookedTicket[DatabaseHelper.columnBookedStatus]),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSectionTitle(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Text(
        title,
        style: Theme.of(context).textTheme.titleLarge?.copyWith(color: primaryPurple, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget _buildDetailRow(String label, String? value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('$label: ', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          Expanded(child: Text(value ?? 'Not provided', style: const TextStyle(fontSize: 16))),
        ],
      ),
    );
  }
}
