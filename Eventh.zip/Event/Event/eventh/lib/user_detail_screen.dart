import 'dart:io';
import 'package:flutter/material.dart';
import 'package:eventh/services/database_helper.dart';
import 'main.dart';

class UserDetailScreen extends StatelessWidget {
  final Map<String, dynamic> user;

  const UserDetailScreen({super.key, required this.user});

  @override
  Widget build(BuildContext context) {
    final profileImagePath = user[DatabaseHelper.columnUserProfileImage] as String?;

    return Scaffold(
      appBar: AppBar(
        title: Text(user[DatabaseHelper.columnUserFullName] ?? 'User Details'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Center(
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 50,
                    backgroundColor: primaryBlue,
                    backgroundImage: profileImagePath != null && profileImagePath.isNotEmpty
                        ? FileImage(File(profileImagePath))
                        : null,
                    child: profileImagePath == null || profileImagePath.isEmpty
                        ? const Icon(Icons.person, size: 60, color: Colors.white)
                        : null,
                  ),
                  const SizedBox(height: 16),
                  Text(
                    user[DatabaseHelper.columnUserFullName] ?? 'No Name',
                    style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    user[DatabaseHelper.columnUserEmail] ?? 'No Email',
                    style: TextStyle(fontSize: 16, color: Colors.grey.shade600),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            Card(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
              elevation: 2,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildDetailRow('ID', user[DatabaseHelper.columnUserId].toString()),
                    _buildDetailRow('Phone Number', user[DatabaseHelper.columnUserPhoneNumber]),
                    _buildDetailRow('Gender', user[DatabaseHelper.columnUserGender]),
                    _buildDetailRow('Location', user[DatabaseHelper.columnUserLocation]),
                    _buildDetailRow('Is Admin', user[DatabaseHelper.columnUserIsAdmin] == 1 ? 'Yes' : 'No'),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String? value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('$label: ', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          Expanded(child: Text(value ?? 'Not provided', style: const TextStyle(fontSize: 16))),
        ],
      ),
    );
  }
}
