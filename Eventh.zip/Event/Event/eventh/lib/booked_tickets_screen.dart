import 'package:flutter/material.dart';
import 'package:eventh/services/database_helper.dart';
import 'package:eventh/view_ticket_screen.dart';

class BookedTicketsScreen extends StatefulWidget {
  final Map<String, dynamic> user;

  const BookedTicketsScreen({super.key, required this.user});

  @override
  State<BookedTicketsScreen> createState() => _BookedTicketsScreenState();
}

class _BookedTicketsScreenState extends State<BookedTicketsScreen> {
  late Future<List<Map<String, dynamic>>> _bookedTicketsFuture;

  @override
  void initState() {
    super.initState();
    final userId = widget.user[DatabaseHelper.columnUserId];
    if (userId != null) {
      _bookedTicketsFuture = DatabaseHelper.instance.getJoinedBookedTickets(userId);
    } else {
      _bookedTicketsFuture = Future.value([]);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: Colors.black),
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: const Text(
          'Booked Tickets',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.black),
        ),
        backgroundColor: Colors.white,
        elevation: 0,
        centerTitle: false,
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: _bookedTicketsFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          }
          final bookedTickets = snapshot.data ?? [];
          if (bookedTickets.isEmpty) {
            return const Center(child: Text('You have no booked tickets.'));
          }
          return ListView.builder(
            itemCount: bookedTickets.length,
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            itemBuilder: (context, index) {
              final bookedTicket = bookedTickets[index];
              return TicketCard(
                event: bookedTicket,
                ticket: bookedTicket,
                onViewTap: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => ViewTicketScreen(
                        bookedTicket: bookedTicket,
                      ),
                    ),
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}

class TicketCard extends StatelessWidget {
  final Map<String, dynamic> event;
  final Map<String, dynamic> ticket;
  final VoidCallback onViewTap;

  const TicketCard(
      {required this.event,
      required this.ticket,
      required this.onViewTap,
      super.key});

  @override
  Widget build(BuildContext context) {
    final Color buttonColor = Theme.of(context).primaryColor;

    return Card(
      margin: const EdgeInsets.only(bottom: 15.0),
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                image: const DecorationImage(
                  image: NetworkImage(
                      "https://placehold.co/60x60/8B5CF6/ffffff?text=E"),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(width: 15),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    event[DatabaseHelper.columnName] ?? 'Event Name',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.black,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Row(
                    children: [
                      const Icon(
                        Icons.calendar_today,
                        size: 14,
                        color: Colors.grey,
                      ),
                      const SizedBox(width: 5),
                      Text(
                        event[DatabaseHelper.columnDate] ?? 'Date',
                        style: const TextStyle(
                          fontSize: 14,
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            Align(
              alignment: Alignment.centerRight,
              child: SizedBox(
                height: 40,
                child: ElevatedButton(
                  onPressed: onViewTap,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: buttonColor,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    elevation: 1,
                  ),
                  child: const Text(
                    'View',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
