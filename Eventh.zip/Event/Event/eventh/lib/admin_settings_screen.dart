import 'package:flutter/material.dart';
import 'package:eventh/services/database_helper.dart';
import 'main.dart';

class AdminSettingsScreen extends StatefulWidget {
  final int userId;
  const AdminSettingsScreen({super.key, required this.userId});

  @override
  _AdminSettingsScreenState createState() => _AdminSettingsScreenState();
}

class _AdminSettingsScreenState extends State<AdminSettingsScreen> {
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  late Future<Map<String, dynamic>?> _adminUserFuture;

  @override
  void initState() {
    super.initState();
    _adminUserFuture = _getAdminUser();
    _adminUserFuture.then((user) {
      if (user != null) {
        _nameController.text = user[DatabaseHelper.columnUserFullName] ?? '';
        _emailController.text = user[DatabaseHelper.columnUserEmail] ?? '';
      }
    });
  }

  Future<Map<String, dynamic>?> _getAdminUser() async {
    return await DatabaseHelper.instance.getUser(widget.userId);
  }

  Future<void> _updateAdminDetails() async {
    final newName = _nameController.text;
    final newEmail = _emailController.text;

    if (newName.isEmpty || newEmail.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Name and email cannot be empty')),
      );
      return;
    }

    final updatedAdmin = {
      DatabaseHelper.columnUserId: widget.userId,
      DatabaseHelper.columnUserFullName: newName,
      DatabaseHelper.columnUserEmail: newEmail,
    };

    await DatabaseHelper.instance.updateUser(updatedAdmin);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Admin details updated successfully!')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Admin Settings'),
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: FutureBuilder<Map<String, dynamic>?>(
          future: _adminUserFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (!snapshot.hasData || snapshot.data == null) {
              return const Center(child: Text('Admin user not found.'));
            }

            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const SizedBox(height: 16),
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Admin Name',
                    prefixIcon: Icon(Icons.person_outline),
                  ),
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _emailController,
                  decoration: const InputDecoration(
                    labelText: 'Admin Email',
                    prefixIcon: Icon(Icons.email_outlined),
                  ),
                ),
                const SizedBox(height: 32),
                ElevatedButton.icon(
                  onPressed: _updateAdminDetails,
                  icon: const Icon(Icons.save_alt),
                  label: const Text('Save Changes'),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
