import 'package:flutter/material.dart';
import 'package:eventh/ticket_confirmation_screen.dart';
import 'package:eventh/services/database_helper.dart';
import 'main.dart';

class PaymentMethodScreen extends StatelessWidget {
  final Map<String, dynamic> event;
  final Map<String, dynamic> ticket;
  final Map<String, dynamic> user;

  const PaymentMethodScreen({super.key, required this.event, required this.ticket, required this.user});

  // This function has been corrected to ensure the dialog is always closed.
  void _showInputDialog(BuildContext context, String title, String hint, Function(String) onConfirm) {
    final controller = TextEditingController();
    showDialog(
      context: context,
      // The context for the dialog is passed as `dialogContext` to avoid confusion.
      builder: (dialogContext) => AlertDialog(
        title: Text(title),
        content: TextField(
          controller: controller,
          decoration: InputDecoration(hintText: hint),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(), // Closes the dialog.
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () {
              // It is critical to close the dialog BEFORE proceeding.
              Navigator.of(dialogContext).pop();
              onConfirm(controller.text);
            },
            child: const Text('Pay'),
          ),
        ],
      ),
    );
  }

  void _confirmBooking(BuildContext context) async {
    final currentUserId = user[DatabaseHelper.columnUserId];

    if (currentUserId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Error: User not found. Cannot book ticket.')),
      );
      return;
    }

    await DatabaseHelper.instance.insertBookedTicket({
      DatabaseHelper.columnBookedEventId: event[DatabaseHelper.columnId],
      DatabaseHelper.columnBookedUserId: currentUserId,
      DatabaseHelper.columnBookedTicketId: ticket[DatabaseHelper.columnTicketId],
      DatabaseHelper.columnBookedStatus: 'Booked',
    });

    final currentQuantity = ticket[DatabaseHelper.columnTicketQuantity] as int;
    await DatabaseHelper.instance.updateTicketQuantity(
      ticket[DatabaseHelper.columnTicketId],
      currentQuantity - 1,
    );

    // Navigate to the confirmation screen with a standard push.
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => TicketConfirmationScreen(event: event, ticket: ticket, user: user),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Select Payment Method'),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.of(context).pop(),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Choose how you want to pay:',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Card(
              child: ListTile(
                leading: const Icon(Icons.credit_card, color: primaryPurple),
                title: const Text('Credit Card'),
                onTap: () => _showInputDialog(context, 'Credit Card', 'Enter your card number', (number) {
                  _confirmBooking(context);
                }),
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.payment, color: primaryPurple),
                title: const Text('PayPal'),
                onTap: () => _showInputDialog(context, 'PayPal Address', 'Enter your email', (email) {
                  _confirmBooking(context);
                }),
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.phone_android, color: primaryPurple),
                title: const Text('MTN Mobile Money'),
                onTap: () => _showInputDialog(context, 'MTN Mobile Money', 'Enter your phone number', (number) {
                  _confirmBooking(context);
                }),
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.phone_android, color: primaryPurple),
                title: const Text('Airtel Money'),
                onTap: () => _showInputDialog(context, 'Airtel Money', 'Enter your phone number', (number) {
                  _confirmBooking(context);
                }),
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.account_balance, color: primaryPurple),
                title: const Text('Bank Account'),
                onTap: () => _showInputDialog(context, 'Bank Account', 'Enter your account number', (number) {
                  _confirmBooking(context);
                }),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
