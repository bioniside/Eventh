import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/event.dart';

class ApiService {
  // Replace with your actual API base URL
  static const String _baseUrl = 'https://my-json-server.typicode.com/typicode/demo';

  // Example function to fetch a list of events from the API
  Future<List<Event>> fetchEvents() async {
    final response = await http.get(Uri.parse('$_baseUrl/posts')); // Using /posts as a stand-in for an events endpoint

    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      // Since the placeholder API returns generic posts, we'll map them to our Event model
      return data.asMap().entries.map((entry) {
        int index = entry.key;
        var post = entry.value;
        return Event(
          id: post['id'] ?? index,
          name: post['title'] ?? 'Event Name',
          date: 'January 1, 2025', // Placeholder date
          location: 'Event Location', // Placeholder location
          description: post['body'] ?? 'No description available.', // Using post body for description
        );
      }).toList();
    } else {
      // Handle API errors (e.g., throw an exception)
      throw Exception('Failed to load events from API');
    }
  }

  // You can add more functions here for POST, PUT, DELETE, etc.
}
