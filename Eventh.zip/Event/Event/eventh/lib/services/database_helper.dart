import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';

class DatabaseHelper {
  static final _databaseName = "Events.db";
  static final _databaseVersion = 13;

  // Events table
  static final eventsTable = 'events';
  static final columnId = '_id';
  static final columnName = 'name';
  static final columnDate = 'date';
  static final columnLocation = 'location';
  static final columnDescription = 'description';
  static final columnImage = 'imagePath';
  static final columnTimestamp = 'timestamp';

  // Users table
  static final usersTable = 'users';
  static final columnUserId = '_id';
  static final columnUserFullName = 'fullName';
  static final columnUserEmail = 'email';
  static final columnUserPassword = 'password';
  static final columnUserProfileImage = 'profileImagePath';
  static final columnUserPhoneNumber = 'phoneNumber';
  static final columnUserGender = 'gender';
  static final columnUserLocation = 'location';
  static final columnUserIsAdmin = 'isAdmin';

  // Tickets table
  static final ticketsTable = 'tickets';
  static final columnTicketId = '_id';
  static final columnTicketEventId = 'eventId';
  static final columnTicketType = 'type';
  static final columnTicketPrice = 'price';
  static final columnTicketQuantity = 'quantity';

  // Booked tickets table
  static final bookedTicketsTable = 'booked_tickets';
  static final columnBookedId = '_id';
  static final columnBookedEventId = 'eventId';
  static final columnBookedUserId = 'userId';
  static final columnBookedTicketId = 'ticketId';
  static final columnBookedStatus = 'status';

  // Notifications table
  static final notificationsTable = 'notifications';
  static final columnNotificationId = '_id';
  static final columnNotificationUserId = 'userId';
  static final columnNotificationTitle = 'title';
  static final columnNotificationBody = 'body';
  static final columnNotificationTimestamp = 'timestamp';
  static final columnNotificationIsRead = 'isRead';

  DatabaseHelper._privateConstructor();
  static final DatabaseHelper instance = DatabaseHelper._privateConstructor();

  static Database? _database;
  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, _databaseName);
    return await openDatabase(
      path,
      version: _databaseVersion,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> _createDefaultAdmin(Database db) async {
    final adminExists = await db.query(
      usersTable,
      where: '$columnUserIsAdmin = ?',
      whereArgs: [1],
    );
    if (adminExists.isEmpty) {
      await db.insert(usersTable, {
        columnUserFullName: 'Bioni',
        columnUserEmail: 'bioni@gmail.com',
        columnUserPassword: 'bioni12',
        columnUserIsAdmin: 1,
      });
    }
  }

  Future _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE $eventsTable (
        $columnId INTEGER PRIMARY KEY,
        $columnName TEXT NOT NULL,
        $columnDate TEXT NOT NULL,
        $columnLocation TEXT NOT NULL,
        $columnDescription TEXT NOT NULL,
        $columnImage TEXT,
        $columnTimestamp INTEGER
      )
    ''');
    await db.execute('''
      CREATE TABLE $usersTable (
        $columnUserId INTEGER PRIMARY KEY,
        $columnUserFullName TEXT NOT NULL,
        $columnUserEmail TEXT NOT NULL UNIQUE,
        $columnUserPassword TEXT NOT NULL,
        $columnUserProfileImage TEXT,
        $columnUserPhoneNumber TEXT,
        $columnUserGender TEXT,
        $columnUserLocation TEXT,
        $columnUserIsAdmin INTEGER NOT NULL DEFAULT 0
      )
    ''');
    await db.execute('''
      CREATE TABLE $ticketsTable (
        $columnTicketId INTEGER PRIMARY KEY,
        $columnTicketEventId INTEGER NOT NULL,
        $columnTicketType TEXT NOT NULL,
        $columnTicketPrice REAL NOT NULL,
        $columnTicketQuantity INTEGER NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE $bookedTicketsTable (
        $columnBookedId INTEGER PRIMARY KEY,
        $columnBookedEventId INTEGER NOT NULL,
        $columnBookedUserId INTEGER NOT NULL,
        $columnBookedTicketId INTEGER NOT NULL,
        $columnBookedStatus TEXT NOT NULL
      )
    ''');
    await db.execute('''
      CREATE TABLE $notificationsTable (
        $columnNotificationId INTEGER PRIMARY KEY,
        $columnNotificationUserId INTEGER NOT NULL,
        $columnNotificationTitle TEXT NOT NULL,
        $columnNotificationBody TEXT NOT NULL,
        $columnNotificationTimestamp INTEGER NOT NULL,
        $columnNotificationIsRead INTEGER NOT NULL DEFAULT 0
      )
    ''');
    await _createDefaultAdmin(db);
  }

  Future _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 11) {
      await db.execute('ALTER TABLE $usersTable ADD COLUMN $columnUserIsAdmin INTEGER NOT NULL DEFAULT 0');
    }
    if (oldVersion < 12) {
      await _createDefaultAdmin(db);
    }
    if (oldVersion < 13) {
      await db.execute('ALTER TABLE $eventsTable ADD COLUMN $columnTimestamp INTEGER');
    }
  }

  Future<void> deleteDatabase() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, _databaseName);
    databaseFactory.deleteDatabase(path);
    _database = null;
  }

  // Event methods
  Future<int> insertEvent(Map<String, dynamic> row) async {
    Database db = await instance.database;
    final newRow = Map<String, dynamic>.from(row);
    newRow[columnTimestamp] = DateTime.now().millisecondsSinceEpoch;
    return await db.insert(eventsTable, newRow);
  }

  Future<Map<String, dynamic>?> getEvent(int eventId) async {
    Database db = await instance.database;
    List<Map<String, dynamic>> events = await db.query(
      eventsTable,
      where: '$columnId = ?',
      whereArgs: [eventId],
    );
    if (events.isNotEmpty) {
      return events.first;
    }
    return null;
  }

  Future<List<Map<String, dynamic>>> queryAllEvents() async {
    Database db = await instance.database;
    return await db.query(eventsTable, orderBy: '$columnTimestamp DESC');
  }

  Future<int> updateEvent(Map<String, dynamic> row) async {
    Database db = await instance.database;
    int id = row[columnId];
    final newRow = Map<String, dynamic>.from(row);
    newRow[columnTimestamp] = DateTime.now().millisecondsSinceEpoch;
    return await db.update(
      eventsTable,
      newRow,
      where: '$columnId = ?',
      whereArgs: [id],
    );
  }

  Future<int> deleteEvent(int id) async {
    Database db = await instance.database;
    return await db.delete(
      eventsTable,
      where: '$columnId = ?',
      whereArgs: [id],
    );
  }

  // User methods
  Future<int> insertUser(Map<String, dynamic> row) async {
    Database db = await instance.database;
    return await db.insert(usersTable, row);
  }

  Future<Map<String, dynamic>?> getUser(int id) async {
    Database db = await instance.database;
    List<Map<String, dynamic>> users = await db.query(
      usersTable,
      where: '$columnUserId = ?',
      whereArgs: [id],
    );
    if (users.isNotEmpty) {
      return users.first;
    }
    return null;
  }

  Future<int> updateUser(Map<String, dynamic> user) async {
    Database db = await instance.database;
    int id = user[columnUserId];
    return await db.update(
      usersTable,
      user,
      where: '$columnUserId = ?',
      whereArgs: [id],
    );
  }

  Future<int> deleteUser(int id) async {
    Database db = await instance.database;
    return await db.delete(
      usersTable,
      where: '$columnUserId = ?',
      whereArgs: [id],
    );
  }

  Future<int> updateUserProfileImage(int userId, String imagePath) async {
    Database db = await instance.database;
    return await db.update(
      usersTable,
      {columnUserProfileImage: imagePath},
      where: '$columnUserId = ?',
      whereArgs: [userId],
    );
  }

  Future<int> updateUserPassword(int userId, String newPassword) async {
    Database db = await instance.database;
    return await db.update(
      usersTable,
      {columnUserPassword: newPassword},
      where: '$columnUserId = ?',
      whereArgs: [userId],
    );
  }

  Future<List<Map<String, dynamic>>> queryAllUsers() async {
    Database db = await instance.database;
    return await db.query(usersTable);
  }

  Future<Map<String, dynamic>?> queryUser(String email) async {
    Database db = await instance.database;
    List<Map<String, dynamic>> users = await db.query(
      usersTable,
      where: '$columnUserEmail = ?',
      whereArgs: [email],
    );
    if (users.isNotEmpty) {
      return users.first;
    }
    return null;
  }

  Future<Map<String, dynamic>?> queryUserByUsernameOrEmail(String identifier) async {
    Database db = await instance.database;
    List<Map<String, dynamic>> users = await db.query(
      usersTable,
      where: '$columnUserFullName = ? OR $columnUserEmail = ?',
      whereArgs: [identifier, identifier],
    );
    if (users.isNotEmpty) {
      return users.first;
    }
    return null;
  }

  // Ticket methods
  Future<int> insertTicket(Map<String, dynamic> row) async {
    Database db = await instance.database;
    return await db.insert(ticketsTable, row);
  }

  Future<int> deleteTicketsForEvent(int eventId) async {
    Database db = await instance.database;
    return await db.delete(
      ticketsTable,
      where: '$columnTicketEventId = ?',
      whereArgs: [eventId],
    );
  }

  Future<List<Map<String, dynamic>>> queryTicketsForEvent(int eventId) async {
    Database db = await instance.database;
    return await db.query(
      ticketsTable,
      where: '$columnTicketEventId = ?',
      whereArgs: [eventId],
    );
  }

  Future<Map<String, dynamic>?> getTicket(int ticketId) async {
    Database db = await instance.database;
    List<Map<String, dynamic>> tickets = await db.query(
      ticketsTable,
      where: '$columnTicketId = ?',
      whereArgs: [ticketId],
    );
    if (tickets.isNotEmpty) {
      return tickets.first;
    }
    return null;
  }

  Future<int> updateTicketQuantity(int ticketId, int newQuantity) async {
    Database db = await instance.database;
    return await db.update(
      ticketsTable,
      {columnTicketQuantity: newQuantity},
      where: '$columnTicketId = ?',
      whereArgs: [ticketId],
    );
  }

  Future<List<Map<String, dynamic>>> queryAllTickets() async {
    Database db = await instance.database;
    return await db.query(ticketsTable);
  }

  // Booked ticket methods
  Future<int> insertBookedTicket(Map<String, dynamic> row) async {
    Database db = await instance.database;
    return await db.insert(bookedTicketsTable, row);
  }

  Future<List<Map<String, dynamic>>> getJoinedBookedTickets(int userId) async {
    Database db = await instance.database;
    return await db.rawQuery('''
      SELECT
        b.$columnBookedId,
        b.$columnBookedStatus,
        e.$columnName,
        e.$columnDate,
        t.$columnTicketType,
        t.$columnTicketPrice,
        u.$columnUserFullName,
        u.$columnUserPhoneNumber
      FROM $bookedTicketsTable b
      JOIN $eventsTable e ON b.$columnBookedEventId = e.$columnId
      JOIN $ticketsTable t ON b.$columnBookedTicketId = t.$columnTicketId
      JOIN $usersTable u ON b.$columnBookedUserId = u.$columnUserId
      WHERE b.$columnBookedUserId = ?
    ''', [userId]);
  }

  Future<List<Map<String, dynamic>>> getAllJoinedBookedTickets() async {
    Database db = await instance.database;
    return await db.rawQuery('''
      SELECT
        b.$columnBookedId,
        b.$columnBookedStatus,
        e.$columnName,
        e.$columnDate,
        e.$columnLocation,
        t.$columnTicketType,
        t.$columnTicketPrice,
        u.$columnUserFullName,
        u.$columnUserEmail,
        u.$columnUserPhoneNumber
      FROM $bookedTicketsTable b
      JOIN $eventsTable e ON b.$columnBookedEventId = e.$columnId
      JOIN $ticketsTable t ON b.$columnBookedTicketId = t.$columnTicketId
      JOIN $usersTable u ON b.$columnBookedUserId = u.$columnUserId
      ORDER BY e.$columnName, u.$columnUserFullName
    ''');
  }

  Future<List<Map<String, dynamic>>> getEventTicketDetails() async {
    final db = await database;
    final List<Map<String, dynamic>> events = await db.query(eventsTable);
    final List<Map<String, dynamic>> eventDetails = [];

    for (var event in events) {
      final eventId = event[columnId];
      final totalTicketsResult = await db.rawQuery(
        'SELECT SUM($columnTicketQuantity) as total FROM $ticketsTable WHERE $columnTicketEventId = ?',
        [eventId],
      );
      final totalTickets = (totalTicketsResult.first['total'] as int?) ?? 0;

      final bookedTicketsResult = await db.rawQuery(
        'SELECT COUNT(*) as booked FROM $bookedTicketsTable WHERE $columnBookedEventId = ?',
        [eventId],
      );
      final bookedTickets = (bookedTicketsResult.first['booked'] as int?) ?? 0;

      eventDetails.add({
        ...event,
        'total_tickets': totalTickets,
        'booked_tickets': bookedTickets,
        'remaining_tickets': totalTickets - bookedTickets,
      });
    }

    return eventDetails;
  }

  Future<List<Map<String, dynamic>>> getBookedUsersForEvent(int eventId) async {
    Database db = await instance.database;
    return await db.rawQuery('''
      SELECT
        u.$columnUserFullName,
        u.$columnUserEmail,
        u.$columnUserPhoneNumber,
        t.$columnTicketType
      FROM $bookedTicketsTable b
      JOIN $usersTable u ON b.$columnBookedUserId = u.$columnUserId
      JOIN $ticketsTable t ON b.$columnBookedTicketId = t.$columnTicketId
      WHERE b.$columnBookedEventId = ?
    ''', [eventId]);
  }

  // Notification methods
  Future<int> insertNotification(Map<String, dynamic> row) async {
    Database db = await instance.database;
    return await db.insert(notificationsTable, row);
  }

  Future<int> clearUserNotifications(int userId) async {
    Database db = await instance.database;
    return await db.delete(
      notificationsTable,
      where: '$columnNotificationUserId = ?',
      whereArgs: [userId],
    );
  }

  Future<List<Map<String, dynamic>>> queryUserNotifications(int userId) async {
    Database db = await instance.database;
    return await db.query(
      notificationsTable,
      where: '$columnNotificationUserId = ?',
      whereArgs: [userId],
      orderBy: '$columnNotificationTimestamp DESC',
    );
  }
}
