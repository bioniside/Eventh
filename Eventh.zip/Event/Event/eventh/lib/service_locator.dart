import 'package:eventh/services/api_service.dart';

// Create a single, global instance of the ApiService
final ApiService apiService = ApiService();
