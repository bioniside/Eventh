import 'package:flutter/material.dart';
import 'package:eventh/services/database_helper.dart';
import 'main.dart'; // For custom colors

class AdminChangePasswordScreen extends StatefulWidget {
  final int userId;
  const AdminChangePasswordScreen({super.key, required this.userId});

  @override
  _AdminChangePasswordScreenState createState() => _AdminChangePasswordScreenState();
}

class _AdminChangePasswordScreenState extends State<AdminChangePasswordScreen> {
  final _oldPasswordController = TextEditingController();
  final _newPasswordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();

  Future<void> _changePassword() async {
    final oldPassword = _oldPasswordController.text;
    final newPassword = _newPasswordController.text;
    final confirmPassword = _confirmPasswordController.text;

    final user = await DatabaseHelper.instance.getUser(widget.userId);

    if (user == null || user[DatabaseHelper.columnUserPassword] != oldPassword) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Old password is not correct')),
      );
      return;
    }

    if (newPassword.isEmpty || newPassword != confirmPassword) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('New passwords do not match or are empty')),
      );
      return;
    }

    await DatabaseHelper.instance.updateUserPassword(widget.userId, newPassword);

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Password updated successfully!')),
    );

    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Change Admin Password'),
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 16),
            TextFormField(
              controller: _oldPasswordController,
              decoration: const InputDecoration(
                labelText: 'Old Password',
                prefixIcon: Icon(Icons.lock_outline),
              ),
              obscureText: true,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _newPasswordController,
              decoration: const InputDecoration(
                labelText: 'New Password',
                prefixIcon: Icon(Icons.lock_person_outlined),
              ),
              obscureText: true,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _confirmPasswordController,
              decoration: const InputDecoration(
                labelText: 'Confirm New Password',
                prefixIcon: Icon(Icons.lock_reset_outlined),
              ),
              obscureText: true,
            ),
            const SizedBox(height: 32),
            ElevatedButton.icon(
              onPressed: _changePassword,
              icon: const Icon(Icons.sync_lock),
              label: const Text('Update Password'),
            ),
          ],
        ),
      ),
    );
  }
}
