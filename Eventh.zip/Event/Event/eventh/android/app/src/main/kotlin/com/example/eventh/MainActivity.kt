package com.example.eventh

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
